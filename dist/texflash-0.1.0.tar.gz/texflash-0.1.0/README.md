# TexFlash

> parse flashcards from latex documents

## Installation

coming soon
