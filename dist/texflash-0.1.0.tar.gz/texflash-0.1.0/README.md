# TexFlash

 > Pain free importing of latex flash cards in anki

 ## Additional Requirements
 - Anki Connect
 - latexmk
 - pdf2svg
